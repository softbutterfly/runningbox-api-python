class Stage:
    RUNNING_BOX_API = 'runningboxapi'
    CROIII = 'croiii'
    # PRODUCTION = 'production'
    TEST = 'test'

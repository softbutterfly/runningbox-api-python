class HttpStatusCode:
    OK = 200
    REDIRECT = 300
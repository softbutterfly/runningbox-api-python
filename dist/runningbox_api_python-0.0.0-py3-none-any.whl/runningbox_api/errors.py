class BadRequestError(Exception):
    pass


class GatewayError(Exception):
    pass


class ServerError(Exception):
    pass


class SignatureVerificationError(Exception):
    pass